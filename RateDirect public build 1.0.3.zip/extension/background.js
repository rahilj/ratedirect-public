chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: 'index.html' });
});

chrome.tabs.onActivated.addListener(function(activeInfo) {
  console.log('activeInfo', activeInfo)
  console.log("Tab activated:", activeInfo.tabId);
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getTabUrl') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabUrl = tabs[0].url;
      sendResponse({ tabUrl: tabUrl });
    });
  }
  return true;
});







